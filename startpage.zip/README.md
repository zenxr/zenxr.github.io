# Start-Page
My firefox start-page. I've removed sensitive URLs, however the general layout is the same.

# Usage
Check [/r/startpages](https://www.reddit.com/r/startpages/) to find out how to use it with your specific browser.

